﻿using System;
using System.Windows.Forms;
using static System.Console;

namespace GreenvilleRevenueGUI
{
    public partial class Form1 : Form
    {
        double Average;
        int firstNum;
        int secondNum;
        int thirdNum;
        int fourthNum;
        int fifthNum;
        int Sum;
        int low;
        int high;
        
        public Form1()
        {
            InitializeComponent();
            lastTextBox.Text = "0";
            thisTextBox.Text = "0";
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "0";
        }

        private void Button1_Click(object sender, EventArgs e)
        {

            firstNum = Convert.ToInt32(lastTextBox.Text);
            secondNum = Convert.ToInt32(thisTextBox.Text);
            thirdNum = Convert.ToInt32(textBox1.Text);
            fourthNum = Convert.ToInt32(textBox2.Text);
            fifthNum = Convert.ToInt32(textBox3.Text);
            Average = (firstNum + secondNum + thirdNum + fourthNum + fifthNum) / 2.0;
            outputLabel1.Text = String.Format("The average is {0}", Average);
        }

        private void LastTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {

            firstNum = Convert.ToInt32(lastTextBox.Text);
            secondNum = Convert.ToInt32(thisTextBox.Text);
            thirdNum = Convert.ToInt32(textBox1.Text);
            fourthNum = Convert.ToInt32(textBox2.Text);
            fifthNum = Convert.ToInt32(textBox3.Text);
            Sum = (firstNum + secondNum + thirdNum + fourthNum + fifthNum);
            label6.Text = String.Format("The sum is {0}", Sum);
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ThisTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            firstNum = Convert.ToInt32(lastTextBox.Text);
            secondNum = Convert.ToInt32(thisTextBox.Text);
            thirdNum = Convert.ToInt32(textBox1.Text);
            fourthNum = Convert.ToInt32(textBox2.Text);
            fifthNum = Convert.ToInt32(textBox3.Text);
            low = firstNum;
            if (secondNum > low)
                high = secondNum;
            if (thirdNum > low)
                high = thirdNum;
            if (fourthNum > low)
                high = fourthNum;
            if (fifthNum > low)
                high = fifthNum;
            label7.Text = String.Format("The lowest number is {0}", low);
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            firstNum = Convert.ToInt32(lastTextBox.Text);
            secondNum = Convert.ToInt32(thisTextBox.Text);
            thirdNum = Convert.ToInt32(textBox1.Text);
            fourthNum = Convert.ToInt32(textBox2.Text);
            fifthNum = Convert.ToInt32(textBox3.Text);
            high = firstNum;
            if (secondNum > high)
                high = secondNum;
            if (thirdNum > high)
                high = thirdNum;
            if (fourthNum > high)
                high = fourthNum;
            if (fifthNum > high)
                high = fifthNum;
            label8.Text = String.Format("The highest number is {0}", high);
        }
    }
}
